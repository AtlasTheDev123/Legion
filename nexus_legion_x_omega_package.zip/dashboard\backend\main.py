﻿from fastapi import FastAPI, HTTPException
import json, os

app = FastAPI(title="NEXUS Legion Dashboard (dev)")
SCHEMAS = os.path.join(os.getcwd(), 'schemas', 'functions.json')

@app.get('/functions')
async def list_functions():
    try:
        with open(SCHEMAS, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get('/health')
async def health():
    return {'status':'ok'}
