﻿# Function Reference

## setup_dev_environment

Create project scaffold, init venv/container, and install base dependencies.

**Parameters**:

- $p: string
- $p: string
- $p: array
\n**Required**: project, language

**Example**:
``json
{
    "project":  "atlas-core",
    "language":  "python",
    "dependencies":  [
                         "fastapi",
                         "pydantic"
                     ]
}
`\n\n## dependency_scan

Run dependency/security scanner over a codebase.

**Parameters**:

- $p: string
- $p: string
- $p: string
\n**Required**: path, tool

**Example**:
``json
{
    "path":  "/projects/atlas-core",
    "tool":  "safety",
    "severity":  "high"
}
`\n\n## run_vulnerability_scan

Run network/vulnerability scan inside an isolated lab (requires lab auth).

**Parameters**:

- $p: string
- $p: string
- $p: string
\n**Required**: target, scan_profile, authorization_token

**Example**:
``json
{
    "target":  "localhost",
    "scan_profile":  "full",
    "authorization_token":  "[REDACTED_LAB_AUTH]"
}
`\n\n## create_remediation_patch

Generate a remediation patch or PR for a known vulnerability.

**Parameters**:

- $p: string
- $p: string
\n**Required**: vuln_id, repo_path

**Example**:
``json
{
    "vuln_id":  "VULN-001",
    "repo_path":  "/projects/atlas-core"
}
`\n\n## run_port_scan

Perform a port scan against a target host or network segment  ONLY with authorization and in isolated lab environments.

**Parameters**:

- $p: string
- $p: string
- $p: string
\n**Required**: target_ip, authorization_token

**Example**:
``json
{
    "target_ip":  "127.0.0.1",
    "ports":  "1-1024",
    "authorization_token":  "[REDACTED_LAB_AUTH]"
}
`\n\n## spawn_agent

Create and start an orchestration agent instance with supplied role and capabilities.

**Parameters**:

- $p: string
- $p: array
- $p: string
\n**Required**: agent_name

**Example**:
``json
{
    "agent_name":  "orchestrator-1",
    "capabilities":  [
                         "scan",
                         "report"
                     ],
    "run_mode":  "dry-run"
}
`\n\n## spawn_subagent

Spawn a short-lived sub-agent to perform a bounded task and return results to the parent agent.

**Parameters**:

- $p: string
- $p: string
- $p: integer
\n**Required**: parent_agent, task

**Example**:
``json
{
    "parent_agent":  "orchestrator-1",
    "task":  "collect-logs",
    "max_runtime_seconds":  120
}
`\n\n## analyze_logs

Analyze collected logs for suspicious patterns and summarize findings.

**Parameters**:

- $p: array
- $p: string
\n**Required**: log_paths

**Example**:
``json
{
    "log_paths":  [
                      "/var/log/auth.log"
                  ],
    "time_window":  "24h"
}
`\n\n## monitor_logs

Start continuous log monitoring with alerting rules (read-only unless authorized).

**Parameters**:

- $p: array
- $p: array
\n**Required**: sources

**Example**:
``json
{
    "sources":  [
                    "/var/log/syslog",
                    "/var/log/app.log"
                ],
    "alert_rules":  [
                        "failed-login",
                        "high-cpu"
                    ]
}
`\n\n## generate_forensics_playbook

Produce a forensics playbook for a detected incident with step-by-step actions.

**Parameters**:

- $p: string
- $p: string
\n**Required**: incident_id, severity

**Example**:
``json
{
    "incident_id":  "INC-001",
    "severity":  "high"
}
`\n\n## create_incident_response_runbook

Generate a runnable incident response runbook with commands and play steps.

**Parameters**:

- $p: string
- $p: array
\n**Required**: incident_id, systems

**Example**:
``json
{
    "incident_id":  "INC-001",
    "systems":  [
                    "web-01",
                    "db-01"
                ]
}
`\n\n## rotate_secrets

Rotate credentials or secrets via secret-store APIs. Requires secure vault permissions and audit.

**Parameters**:

- $p: string
- $p: string
- $p: boolean
\n**Required**: secret_id, vault

**Example**:
``json
{
    "secret_id":  "svc/db-user",
    "vault":  "azure-key-vault",
    "force":  false
}
`\n\n## deploy_application

Deploy an application artifact to a target environment (staging/production) using approved pipelines.

**Parameters**:

- $p: string
- $p: string
- $p: string
\n**Required**: artifact_id, environment

**Example**:
``json
{
    "artifact_id":  "atlas-core:1.2.3",
    "environment":  "staging",
    "strategy":  "canary"
}
`\n\n## monitor_performance

Collect and summarize performance metrics for services over a time window.

**Parameters**:

- $p: string
- $p: array
- $p: string
\n**Required**: service, metrics

**Example**:
``json
{
    "service":  "atlas-api",
    "metrics":  [
                    "cpu",
                    "latency"
                ],
    "time_window":  "1h"
}
`\n\n## generate_architecture_diagram

Produce a system architecture diagram (textual or mermaid) from code / infra descriptions.

**Parameters**:

- $p: string
- $p: string
\n**Required**: source

**Example**:
``json
{
    "source":  "infra/tf",
    "format":  "mermaid"
}
`\n\n## create_bug_bounty_scope

Draft an authorized bug bounty program scope and disclosure guidelines for a product or service.

**Parameters**:

- $p: string
- $p: array
- $p: array
- $p: array
\n**Required**: product_name, in_scope, out_of_scope

**Example**:
``json
{
    "product_name":  "Atlas Core",
    "in_scope":  [
                     "api.example.com"
                 ],
    "out_of_scope":  [
                         "admin.example.com"
                     ],
    "reward_tiers":  [
                         {
                             "severity":  "critical",
                             "reward_usd":  2000
                         }
                     ]
}
`\n\n## generate_supplemental_docs_for_audit

Produce documentation artifacts required for compliance audits (evidence mapping, config snapshots, control descriptions).

**Parameters**:

- $p: string
- $p: string
- $p: array
\n**Required**: compliance_standard, unit

**Example**:
``json
{
    "compliance_standard":  "ISO27001",
    "unit":  "payments",
    "evidence_paths":  [
                           "/audit/evidence/2025-10"
                       ]
}
`\n\n## create_access_token_policy

Draft a policy for short-lived access tokens, lifetimes, scopes, and rotation rules.

**Parameters**:

- $p: integer
- $p: array
- $p: integer
\n**Required**: token_lifetime_minutes, scopes

**Example**:
``json
{
    "token_lifetime_minutes":  60,
    "scopes":  [
                   "read:logs",
                   "write:deploy"
               ],
    "rotation_frequency_days":  7
}
`\n\n## generate_privilege_escalation_hunt

Create detection rules and hunt playbooks for common privilege escalation patterns.

**Parameters**:

- $p: string
- $p: array
\n**Required**: environment

**Example**:
``json
{
    "environment":  "aws",
    "deliverables":  [
                         "sigma_rule",
                         "playbook.md"
                     ]
}
`\n\n## create_privacy_data_map

Map personal data flows across systems and produce retention and minimization recommendations.

**Parameters**:

- $p: array
- $p: array
\n**Required**: systems, data_types

**Example**:
``json
{
    "systems":  [
                    "auth-service",
                    "marketing-db"
                ],
    "data_types":  [
                       "email",
                       "ssn"
                   ]
}
`\n\n## generate_backup_strategy

Design a backup and restore strategy including retention, encryption, and recovery objectives.

**Parameters**:

- $p: array
- $p: integer
- $p: integer
\n**Required**: systems, rpo_hours, rto_hours

**Example**:
``json
{
    "systems":  [
                    "db-primary"
                ],
    "rpo_hours":  1,
    "rto_hours":  4
}
`\n\n## create_malware_analysis_lab

Design an isolated analysis lab environment with VM/container specs, network isolation, and tooling lists.

**Parameters**:

- $p: string
- $p: string
- $p: array
\n**Required**: lab_name, isolation_level

**Example**:
``json
{
    "lab_name":  "malware-lab-1",
    "isolation_level":  "vm",
    "tools":  [
                  "cuckoo",
                  "ghidra"
              ]
}
`\n\n## generate_malicious_sample_handling_policy

Draft safe handling and storage policies for potentially malicious samples, including chain-of-custody and retention.

**Parameters**:

- $p: string
- $p: string
- $p: string
\n**Required**: organization_name, responsible_team

**Example**:
``json
{
    "organization_name":  "ATLAS",
    "responsible_team":  "ThreatOps",
    "storage_requirements":  "encrypted, airgapped"
}
`\n\n## create_privileged_account_onboarding

Produce an onboarding checklist and required controls for privileged accounts.

**Parameters**:

- $p: string
- $p: array
\n**Required**: account_type, required_controls

**Example**:
``json
{
    "account_type":  "ops_admin",
    "required_controls":  [
                              "mfa",
                              "just-in-time",
                              "audit_logging"
                          ]
}
`\n\n## generate_compliance_gap_analysis

Compare current controls to a target compliance standard and produce prioritized remediation items.

**Parameters**:

- $p: string
- $p: array
\n**Required**: standard, evidence_paths

**Example**:
``json
{
    "standard":  "SOC2",
    "evidence_paths":  [
                           "/audit/logs"
                       ]
}
`\n\n## create_change_management_plan

Create a change management plan with approval flows, rollback criteria, and communication steps.

**Parameters**:

- $p: string
- $p: string
- $p: array
\n**Required**: change_id, impact_level, stakeholders

**Example**:
``json
{
    "change_id":  "CHG-123",
    "impact_level":  "medium",
    "stakeholders":  [
                         "ops",
                         "sec"
                     ]
}
`\n\n## generate_runbook_for_operation

Produce an operational runbook with step-by-step commands, diagnostics, and recovery procedures for routine operations.

**Parameters**:

- $p: string
- $p: string
- $p: array
\n**Required**: operation_name, platform

**Example**:
``json
{
    "operation_name":  "monthly_backup_validate",
    "platform":  "k8s",
    "checklist":  [
                      "verify-snapshots",
                      "restore-test"
                  ]
}
`\n\n
